console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA BELOW ONLY! *** */








  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA ABOVE ONLY! *** */
  
});