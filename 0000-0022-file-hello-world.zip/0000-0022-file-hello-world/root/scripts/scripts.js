console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');
  
  var myEl = document.getElementById('myHeading');
  myEl.innerText = 'Hello Stefan';

 
  myEl.style.color = 'red';
  
});