console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA BELOW ONLY! *** */


  
  // Select the HTML heading element with the ID myHeading 
  // and assign this object to myEl
  var myEl = document.getElementById('myHeading');
  
  // Change the inner text of the selected element by assigning
  // a new value to the innerText property of the myEl object
  myEl.innerText = 'Hello Stefan';

  // This is just to tease you, we will learn about many
  // different build-in objects and methods at a later stage.
  myEl.style.color = 'red';




  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA ABOVE ONLY! *** */
});