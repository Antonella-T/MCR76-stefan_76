console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA BELOW ONLY! *** */

  var box1 = document.getElementById('box1');
  var box2 = document.getElementById('box2');

  box1.style.color = 'orange';
  box1.style.fontSize = '25px';




  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA ABOVE ONLY! *** */
  
});