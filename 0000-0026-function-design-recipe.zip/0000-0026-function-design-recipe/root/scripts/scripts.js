console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA BELOW ONLY! *** */





  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE THE AREA ABOVE ONLY! *** */
  
});


/* Demonstrate the function design recipe to create a
   function that adds two numbers. Below example solves 
   a simple coding problem (+ operation)that could be 
   solved without the use of a function. This has been 
   chosen for creating a simple example of the
   Function Design Recipe.

   Source: https://mycourseresource.com/software-development/tn200902002-function-design-recipe.php

*/
   
   
/**
 * add two numbers
 * @param {Number} numA - first number for adding
 * @param {Number} numB - second number for adding
 * @return {Number} - result of adding first and second number
 *
 * numSum(13, 7)
 * returns 20
 * numSum(7, 13)
 * returns 20
 * numSum(13, -7)
 * returns 6
 * numSum(-13, 7)
 * returns -6
 * numSum(14, -14)
 * returns 0
 *
 * STRATEGY: Make use of JavaScript's '+' operand
 */
function numSum(numA, numB) {
  return numA + numB;	
}




var result = numSum(13, 7);
console.log('13 + 7 = ' + result + ' (Should be 20)')
result = numSum(7, 13);
console.log('7 + 13 = ' + result + ' (Should be 20)')
result = numSum(13, -7);
console.log('13 + -7 = ' + result + ' (Should be 6)')
result = numSum(-13, 7);
console.log('-13 + 7 = ' + result + ' (Should be -6)')
result = numSum(14, -14);
console.log('14 + -14 = ' + result + ' (Should be 0)')


