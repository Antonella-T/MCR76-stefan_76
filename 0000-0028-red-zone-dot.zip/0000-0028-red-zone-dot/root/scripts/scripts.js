console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA BELOW ONLY! *** */








  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA ABOVE ONLY! *** */
  
});




/**
  * To change the colour of an element when it is clicked
  * @param {string} objectId - the ID of object to be manipulated
  * @return {Boolean} - true if function executed to the end
  *
  * changeColor()
  * true
  *
  * STRATEGY: Manipulate the JS style object to change bg colours
  */ 
function changeColor(objectId) {
  // INPUT the HTML object to be manipulated
  var htmlObj = document.getElementById(objectId);

  // change the colour of the HTML element
  htmlObj.style.backgroundColor = 'pink';
  return true;
}