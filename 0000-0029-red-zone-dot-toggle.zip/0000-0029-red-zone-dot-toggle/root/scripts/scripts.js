console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA BELOW ONLY! *** */








  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA ABOVE ONLY! *** */
  
});




/**
  * To toggle the colour of an element when it is clicked
  * @param {string} objectId - the ID of object to be manipulated
  * @return {Boolean} - true if function executed to the end
  *
  * toggleColor()
  * true
  *
  * STRATEGY: Use the JS style object to manipulate bg colours
  */ 
function toggleColor(objectId) {
  // INPUT the HTML object to be manipulated and assign to htmlObj
  var htmlObj = document.getElementById(objectId);

  if (htmlObj.style.backgroundColor == 'pink') {
    // change the colour of the HTML element
    htmlObj.style.backgroundColor = 'red';
	}
  else {
    // change the colour of the HTML element
    htmlObj.style.backgroundColor = 'pink';
	}
  return true;	
}