console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();  
    
});


var divWidth = 50; // same value as set in CSS


function addMyEventListeners() {
  document.getElementById('colorDot').addEventListener('mouseover', changeColorPink);	
  document.getElementById('colorDot').addEventListener('mouseout', changeColorRed);
  document.getElementById('colorDot').addEventListener('dblclick', alertMe);
  document.getElementById('colorDot').addEventListener('wheel', resizeDiv);
}


function changeColorPink() {
  console.log('changeColorPink called!');
  // INPUT the HTML object to be manipulated and assign to htmlObj
  var htmlObj = document.getElementById('colorDot');
  // change the colour of the HTML element
  htmlObj.style.backgroundColor = 'pink';
  return true;	
}

function changeColorRed() {
  console.log('changeColorRed called!');
  // INPUT the HTML object to be manipulated and assign to htmlObj
  var htmlObj = document.getElementById('colorDot');
  // change the colour of the HTML element
  htmlObj.style.backgroundColor = 'red';
  return true;	
}

function alertMe() {
  console.log('alertMe called!');
  alert('Hello to you double clicker :)');
}


function resizeDiv() {
  if (detectWheelDirection() == 'up') {
    divWidth+= 1;
  }
  else {
    divWidth-= 1;
  }
  console.log('resizeDiv called! divWidth=' + divWidth);
  document.getElementById('colorDot').style.width = divWidth + '%';
}


/* Below function is an advance method to capture events 
   that we'll cover at a later stage */
function detectWheelDirection(e) {
  var delta = null, direction = false;
  if (!e) { // if the event is not provided, we get it from the window object
    e = window.event;
  }
  if ( e.wheelDelta ) { // will work in most cases
    delta = e.wheelDelta / 60;
  }
  else if ( e.detail ) { // fallback for Firefox
    delta = -e.detail / 2;
  }
  if ( delta !== null ) {
    direction = delta > 0 ? 'up' : 'down';
  }
  return direction;
}