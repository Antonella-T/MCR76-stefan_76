console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();  
    
});


function addMyEventListeners() {
  document.getElementById('colorDot').addEventListener('mouseover', changeColorPink);	
  document.getElementById('colorDot').addEventListener('mouseout', changeColorRed);
  document.getElementById('colorDot').addEventListener('dblclick', alertMe);
  document.getElementById('colorDot').addEventListener('wheel', resizeDiv);
}


function changeColorPink() {
  console.log('changeColorPink called!');
  // INPUT the HTML object to be manipulated and assign to htmlObj
  var htmlObj = document.getElementById('colorDot');
  // change the colour of the HTML element
  htmlObj.style.backgroundColor = 'pink';
  return true;	
}

function changeColorRed() {
  console.log('changeColorRed called!');
  // INPUT the HTML object to be manipulated and assign to htmlObj
  var htmlObj = document.getElementById('colorDot');
  // change the colour of the HTML element
  htmlObj.style.backgroundColor = 'red';
  return true;	
}

function alertMe() {
  console.log('alertMe called!');
  alert('Hello to you double clicker :)');
}


function resizeDiv() {
  console.log('resizeDiv called!');
  document.getElementById('colorDot').style.width = '20%';
}