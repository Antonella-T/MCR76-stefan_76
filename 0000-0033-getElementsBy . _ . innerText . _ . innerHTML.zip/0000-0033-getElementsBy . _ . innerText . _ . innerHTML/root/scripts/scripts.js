console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  htmlSelectObjectExercise();
    
});



// Default variable declarations for variables we are likely to use:
var i;



/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

}



// Function that we want to use to demonstrate the different selection methods.
function htmlSelectObjectExercise(){

  // This is what we already know ....
  var divWithId = document.getElementById('theDiv');
  divWithId.style.backgroundColor = 'blue';
  divWithId.style.color = 'white';


  
  // Access HTML elements by Class
  var divWithClass_myDiv = document.getElementsByClassName('myDiv');
  
  // Change style of each element one-by-one
  divWithClass_myDiv[0].style.border = '3px solid navy';
  divWithClass_myDiv[1].style.border = '3px solid navy';
  divWithClass_myDiv[2].style.border = '3px solid navy';
  divWithClass_myDiv[3].style.border = '3px solid navy';
  divWithClass_myDiv[4].style.border = '3px solid navy';
  divWithClass_myDiv[5].style.border = '3px solid navy';
  
  // Change style of each element with a loop

  for (i = 0; i < divWithClass_myDiv.length; i++) {
    divWithClass_myDiv[i].style.backgroundColor = 'white';
  }

  /* ... and if we know that there is only one element with a class that we 
         want to change ....     */
  var oneDivWithClass = document.getElementsByClassName('extraDiv');
  oneDivWithClass[0].style.border = '3px solid red';

  
 
  // Access HTML elements by Tag
  var divWithTag_div = document.getElementsByTagName('div');
  for (i = 0; i < divWithTag_div.length; i++) {
    divWithTag_div[i].style.margin = '10px';
	divWithTag_div[i].style.padding = '10px';
  }



  // Access HTML elements with querySelectorAll
  var divWithQuery = document.querySelectorAll('div.twoDivs');
  console.log(divWithQuery);  
  for (i = 0; i < divWithQuery.length; i++) {
    // innerText just adds plain text
    divWithQuery[i].innerText = 'This div is the ' + 
	                            (i + 1) + '. div with the twoDivs class.';
  }

  var divWithQuery = document.querySelectorAll('div.others');
  console.log(divWithQuery);  
  for (i = 0; i < divWithQuery.length; i++) {
    // innerHTML can be used to add HTML elements and plain text
    divWithQuery[i].innerHTML = '<p>This div is the ' + 
	                            (i + 1) + '. div with the others class :).</p>';
  }


  // Another innerHTML example to add HTML elements dynamically to a page
  divWithId.innerHTML = '<p>This page introduced you to:</p><ul>' +
                        '<li>getElementById</li>' + 
						'<li>getElementsByClassName</li>' + 
						'<li>getElementsByTagName</li>' + 
						'<li>querySelectorAll</li>' + 
						'</ul>';
  /* Add the listStylePosition CSS property to ensure the 
     bullet point of the list stay within the div container.     */
  divWithId.style.listStylePosition = 'inside';

 
}
