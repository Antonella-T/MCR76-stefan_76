console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  document.getElementById('divContainer1').style.backgroundColor = 'green';
  document.getElementById('divContainer2').style.backgroundColor = 'olive';
  document.getElementById('divContainer3').style.backgroundColor = 'orange';
  document.getElementById('divContainer4').style.backgroundColor = 'pink';
  document.getElementById('divContainer5').style.backgroundColor = 'purple';
  document.getElementById('divContainer6').style.backgroundColor = 'lightgreen';
  
});



// Default variable declarations for variables we are likely to use:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementById('divContainer1').addEventListener('click', function() {
    divClicked(this);
  });
  document.getElementById('divContainer2').addEventListener('click', function() {
    divClicked(this);
  });
  
  var divByClassName = document.getElementsByClassName('classNameExample');
  for (i = 0; i < divByClassName.length; i++) {
    divByClassName[i].addEventListener('click', function() {
    divClicked(this);
  });
  }
}






function divClicked(divNo) {
  console.log(divNo.id + ' was clicked ...');
  console.log('... this div has ' + divNo.style.backgroundColor + ' as bg colour');
}
