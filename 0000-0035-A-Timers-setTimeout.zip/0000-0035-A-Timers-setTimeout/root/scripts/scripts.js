console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});



// Default variable declarations for variables we are likely to use:
var i;
var myTimer;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementById('startTimer').addEventListener('click', timerStart);
  document.getElementById('cancelTimer').addEventListener('click', timerCancel);
}


function timerStart() {
  console.log('Timer Starting');
  myTimer = setTimeout(displayTimeElapsedMessage, 5000);
}

function timerCancel() {
  console.log('Timer Cancelled');
  clearTimeout(myTimer);
}

function displayTimeElapsedMessage() {
  console.log('Timer Ended');
}