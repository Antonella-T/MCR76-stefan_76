console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});



// Default variable declarations for variables we are likely to use:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

}

function changeImage1() {
  document.getElementById('image1').style.zIndex = "9999";
  document.getElementById('image2').style.zIndex = "0";
  document.getElementById('image3').style.zIndex = "0";
  document.getElementById('image4').style.zIndex = "0"; 
}

function changeImage2() {
  document.getElementById('image1').style.zIndex = "0";
  document.getElementById('image2').style.zIndex = "9999";
  document.getElementById('image3').style.zIndex = "0";
  document.getElementById('image4').style.zIndex = "0"; 
}

function changeImage3() {
  document.getElementById('image1').style.zIndex = "0";
  document.getElementById('image2').style.zIndex = "0";
  document.getElementById('image3').style.zIndex = "9999";
  document.getElementById('image4').style.zIndex = "0"; 
}

function changeImage4() {
  document.getElementById('image1').style.zIndex = "0";
  document.getElementById('image2').style.zIndex = "0";
  document.getElementById('image3').style.zIndex = "0";
  document.getElementById('image4').style.zIndex = "9999"; 
}
