console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});



// Default variable declarations for variables we are likely to use:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementById('button1').addEventListener('click', changeImage1);
  document.getElementById('button2').addEventListener('click', changeImage2);
  document.getElementById('button3').addEventListener('click', changeImage3);
  document.getElementById('button4').addEventListener('click', changeImage4);
}

function changeImage1() {
  moveImagesToBack();
  document.getElementById('image1').style.zIndex = "9999";
}

function changeImage2() {
  moveImagesToBack();
  document.getElementById('image2').style.zIndex = "9999";
}

function changeImage3() {
  moveImagesToBack();
  document.getElementById('image3').style.zIndex = "9999";
}

function changeImage4() {
  moveImagesToBack();
  document.getElementById('image4').style.zIndex = "9999"; 
}

function moveImagesToBack() {
  document.getElementById('image1').style.zIndex = "0";
  document.getElementById('image2').style.zIndex = "0";
  document.getElementById('image3').style.zIndex = "0";
  document.getElementById('image4').style.zIndex = "0";
  return;
}