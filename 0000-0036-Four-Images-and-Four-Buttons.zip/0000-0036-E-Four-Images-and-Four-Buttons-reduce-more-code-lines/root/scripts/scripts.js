console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  images = document.getElementsByClassName('images');
  
});



// Default global variable declarations for variables we are likely to use:
var i;
var images;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementById('button1').addEventListener('click', function(){
  changeImage('image1')});
  document.getElementById('button2').addEventListener('click', function(){
  changeImage('image2')});
  document.getElementById('button3').addEventListener('click', function(){
  changeImage('image3')});
  document.getElementById('button4').addEventListener('click', function(){
  changeImage('image4')});
}

function changeImage(imgId) {
  moveImagesToBack();
  document.getElementById(imgId).style.zIndex = "9999";
}


function moveImagesToBack() { 
  for(i = 0; i < images.length; i++){
    images[i].style.zIndex = '0';
  }
  return;
}