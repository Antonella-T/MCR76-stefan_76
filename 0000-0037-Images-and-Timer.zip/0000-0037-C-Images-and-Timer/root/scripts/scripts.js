console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  console.log(initializeAlternator()[0]);
  console.log(initializeAlternator()[1]);
  
  displayImage('image1', initializeAlternator()[1]);
  
});



// Default global variable declarations for variables we are likely to use:
var i = 0;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  //document.getElementById('buttonStart').addEventListener('click', function(){
  //timerStart()});
  //document.getElementById('buttonStop').addEventListener('click', function(){
  //timerStop()});
}


/**
 * initialize alternator as used for alternating images
 * @param {n/a} n/a - no values as parameters
 * @return {Array} - 1. item counter i {Number} and 2. item images {Array}
 *
 * examples are not available
 * 
 * STRATEGY: Assign 0 to counter i and use getElementsByClassName for images
 *
 */
function initializeAlternator() {
  // counter i = 0
  var i = 0;
  // get objects with class 'images' and assign to variable images
  var images = document.getElementsByClassName('images');
  return [i, images];  
}



/**
 * hides all images and places the selected image on top of stack
 * @param {String} idImageShow - id of the image to be placed on top of stack
 * @param {Array} images - the array of images found on HTML page
 * @return {n/a} - no return value
 *
 * examples are not available
 * 
 * STRATEGY: Use JS loop for setting zIndices to 0 and getElementById for current image
 *
 */
function displayImage(idImageShow, images) {
  // set zIndex of all images to 0
  for (i = 0; i < images.length; i++) {
    images[i].style.zIndex = '0';
  }
  // set zIndex of current image to 9999
  document.getElementById(idImageShow).style.zIndex = '9999';
}

