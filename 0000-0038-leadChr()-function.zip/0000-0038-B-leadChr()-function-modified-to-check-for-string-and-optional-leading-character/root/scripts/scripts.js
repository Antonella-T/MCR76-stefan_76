console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();


  console.log("leadChar('A', 4) returns '" + leadChar('A', 4) + "', expected '   A'");
  console.log("leadChar('A', 4, 'x') returns '" + leadChar('A', 4, 'x') + "', expected 'xxxA'");
  console.log("leadChar('X', 2) returns '" + leadChar('X', 2) + "', expected ' X'");
  console.log("leadChar(0, 4) returns '" + leadChar(0, 4) + "', expected 'false'");
  console.log("leadChar('0', 4) returns '" + leadChar('0', 4) + "', expected '   0'");
  console.log("leadChar('9', 2, '0') returns '" + leadChar('9', 2, '0') + "', expected '09'");
  console.log("leadChar('O', 4) returns '" + leadChar('O', 4) + "', expected '   O'");
  console.log("leadChar('A', 0) returns '" + leadChar('A', 0) + "', expected ''");
  console.log("leadChar('AB', 1) returns '" + leadChar('AB', 1) + "', expected 'B'");

   
});


// Global variable declarations for variables used or likely to be used:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

}



/**
 * pad a string with leading characters and trim to a specified length
 * @param {String} str - the string to be padded
 * @param {Number} len - the specified total length of the returned string
 * @param {String} [chr=' '] - the optional character used as the leading 
 *                             character (default: chr=' ')
 * @return {String} - the padded string
 *
 * leadChar('A', 4)
 * returns '   A'
 * leadChar('A', 4, 'x')
 * returns 'xxxA'
 * leadChar('X', 2)
 * returns ' X'
 * leadChar(0, 4)
 * returns false
 * leadChar('0', 4)
 * returns '   0'
 * leadChar('9', 2, '0')
 * returns '09'
 * leadChar('O', 4)
 * returns '   O'
 * leadChar('A', 0)
 * returns ''
 * leadChar('AB', 1)
 * returns 'B'
 * 
 * STRATEGY: Use substr()or slice() to trim the string to the specified length
 *
 */
function leadChar(str, len, chr) {
  // Return false if string to be padded is not of data type string
  if (typeof str !== 'string') {
    return false;
  }
  
  // Check if value for chr was passed, if not set chr to ' '
  chr = chr || " ";
  
  // Create an empty string
  var leading = '';
  
  // Add as many spaces as the specified length
  for (i = 0; i < len; i++) {
    leading += chr;
	//console.log("'" + leading + "'");
  }
  // Remove redundant leading characters
  return (leading + str).slice(len * -1);
}

