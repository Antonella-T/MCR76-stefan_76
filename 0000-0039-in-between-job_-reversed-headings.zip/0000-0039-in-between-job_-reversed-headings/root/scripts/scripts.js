console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  // To test the reverseCharacters() function:
  console.log(reverseCharacters('FIRE SERVICES'));
  
});


// Global variable declarations for variables used or likely to be used:
var i;
var j;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementById('testButton').addEventListener('click', reverseHeadings);
}


function reverseHeadings() {
  // Capture all page headings and assign to pageHeads
  var pageHeads = capturePageHeads();
  // Reverse all characters of each pageHeads element
  for (i = 0; i < pageHeads.length; i++) {
    for (j = 0; j < pageHeads[i].length; j++) {
      pageHeads[i][j] = reverseCharacters(pageHeads[i][j]);
    }
  }
  // Replace each page heading with modified (reversed) pageHeads
  replacePageHeads(pageHeads);
}




/**
 * Captures all heading elements and assigns by heading type to sub arrays
 * @param {n/a} n/a - no parameters required
 * @return {Array} - Array of arrays, one array for each heading type
 *
 * [[h1's],[h2's],[h3's],[h4's],[h5's],[h6's]]
 *
 * STRATEGY: Avail of getElementsByTagName for each heading type and
 *           loop for each heading type to capture the innerText
 */
function capturePageHeads(){
  var h1Elements = document.getElementsByTagName('h1');
  var h2Elements = document.getElementsByTagName('h2');
  var h3Elements = document.getElementsByTagName('h3');
  var h4Elements = document.getElementsByTagName('h4');
  var h5Elements = document.getElementsByTagName('h5');
  var h6Elements = document.getElementsByTagName('h6');
  var h1s = [];
  var h2s = [];
  var h3s = [];
  var h4s = [];
  var h5s = [];
  var h6s = [];
  for (i = 0; i < h1Elements.length; i++) {
	  h1s.push(h1Elements[i].innerText)
  }
  for (i = 0; i < h2Elements.length; i++) {
	  h2s.push(h2Elements[i].innerText)
  }
  for (i = 0; i < h3Elements.length; i++) {
	  h3s.push(h3Elements[i].innerText)
  }
  for (i = 0; i < h4Elements.length; i++) {
	  h4s.push(h4Elements[i].innerText)
  }
  for (i = 0; i < h5Elements.length; i++) {
	  h5s.push(h5Elements[i].innerText)
  }
  for (i = 0; i < h6Elements.length; i++) {
	  h6s.push(h6Elements[i].innerText)
  }
  return [h1s, h2s, h3s, h4s, h5s, h6s];
}





/**
 * replaces all heading elements based on pageHeads array
 * @param {Array} pageHeads - Array of arrays, one array for each heading type
 * @return {Boolean} - returns true
 *
 * replacePageHeads(pageHeads)
 * returns true
 *
 * STRATEGY: Avail of getElementsByTagName for each heading type and
 *           loop for each heading type to replace the innerText
 */
function replacePageHeads(pageHeads){
  var h1Elements = document.getElementsByTagName('h1');
  var h2Elements = document.getElementsByTagName('h2');
  var h3Elements = document.getElementsByTagName('h3');
  var h4Elements = document.getElementsByTagName('h4');
  var h5Elements = document.getElementsByTagName('h5');
  var h6Elements = document.getElementsByTagName('h6');
  for (i = 0; i < h1Elements.length; i++) {
	  h1Elements[i].innerText = pageHeads[0][i];
  }
  for (i = 0; i < h2Elements.length; i++) {
	  h2Elements[i].innerText = pageHeads[1][i];
  }
  for (i = 0; i < h3Elements.length; i++) {
	  h3Elements[i].innerText = pageHeads[2][i];
  }  
  for (i = 0; i < h4Elements.length; i++) {
	  h4Elements[i].innerText = pageHeads[3][i];
  }  
  for (i = 0; i < h5Elements.length; i++) {
	  h5Elements[i].innerText = pageHeads[4][i];
  }  
  for (i = 0; i < h6Elements.length; i++) {
	  h6Elements[i].innerText = pageHeads[5][i];
  }  
  return true;
}





/**
 * Reverses the characters of a string (back to front)
 * @param {String} chars - the string with characters to be reversed
 * @return {String} - the reversed character
 *
 * reverseCharacters('FIRE SERVICES')
 * returns 'SECIVRES ERIF'
 *
 * STRATEGY: Array.reverse() method 
 */
function reverseCharacters(chars){
  var charsArray = chars.split('');
  charsArray.reverse();
  return charsArray.join('');
}
