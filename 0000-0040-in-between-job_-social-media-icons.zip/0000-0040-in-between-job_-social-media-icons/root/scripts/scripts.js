console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  console.log(moveElement());
  
});


// Global variable declarations for variables used or likely to be used:
var i;
var j;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  document.getElementsByTagName('body')[0].addEventListener('resize', moveElement);
}



/**
 * Move an HTML element from position x (Desktop) to position y (Mobile) 
 * based in browser width.
 * @param {n/a} n/a - not required as no values are passed into this function
 * @return {boolean} - true for Mobile size and false for Desktop size
 * 
 * moveElement()
 * returns true - for Desktop, e.g. bWidth > bSwitch
 * moveElement()
 * returns false - for Mobile, e.g. bWidth not > bSwitch
 * 
 * STRATEGY: Use window.innerWidth to find value for bWidth
 */ 
function moveElement() {
  // Capture browser width and assign to bWidth
  var bWidth = window.innerWidth;
  // DEFINE switching point to 500px and assign to bSwitch
  var bSwitch = 500;
  // Capture HTML element for moving and assign to htmlEl
  var htmlEl = document.getElementById('social');
  // DEFINE position x for Desktop and assign 10 px to posXTop and 150px to posXRight
  var posXTop = 10;
  var posXRight = 150;
  // DEFINE position y for Mobile and assign 50 px to posYBottom and 0px to posYRight
  var posYBottom = 50;
  var posYRight = 0;
  // IF bWidth > bSwitch:
  if (bWidth > bSwitch){
    // Move element to position x
	htmlEl.style.top = posXTop +'px';
	htmlEl.style.bottom = 'auto';
	htmlEl.style.right = posXRight +'px';
	htmlEl.style.transform = 'rotate(0deg)';
	return true;
  }
  //ELSE:
  else {
    // Move element to position y
	htmlEl.style.top = 'auto';
	htmlEl.style.bottom = (posYBottom - htmlEl.offsetHeight/2 + htmlEl.offsetWidth/2) +'px';
	htmlEl.style.right = (posYRight + htmlEl.offsetHeight/2 - htmlEl.offsetWidth/2) +'px';
	htmlEl.style.transform = 'rotate(90deg)';
	return false;
  }
}

