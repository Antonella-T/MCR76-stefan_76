console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});


// Global variable declarations for variables used or likely to be used:
var i;
var j;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

// JS anonymous function as argument to other functions, e.g. addEventListener
  document.getElementById('aBox').addEventListener('click', function() {
    console.log('JS anonymous function used as argument has been clicked');
  });

}



// function basics arguments and parameters
function addNumbers(x, y) {   // x and y are both parameters that take on values passed into the function
  console.log('x + y =', x + y);
}

addNumbers(3, 6);  // 3 and 6 are both arguments that we pass into the addNumbers function

var a = 4;
var b = 7;
addNumbers(a, b);  // a and b are both arguments that we pass into the addNumbers function




// JS anonymous function are immediately invoked (called). 
// They are also called self-invoked functions or they are also
// called Immediately-invoked Function Expressions (IIFE)

var x = function() {
  console.log('JS anonymous function assigned to x');
};
x();

//above is nothing else except a different notation for:
function x() {
  console.log('JS function named x');
};
x();



// Immediately-invoked Function Expressions (IIFE)
(function() {
  console.log('JS anonymous function used as IIFE');
})();



// Immediately-invoked Function Expressions (IIFE) and global variable scope
var a = 6; 
(function() {
  console.log('Inside the IIFE, variable a has value: ', a);
})();
console.log('After invoking IIFE, variable a has value: ', a);
// Value of a is available to the IIFE as a is a global variable



// Immediately-invoked Function Expressions (IIFE) and global variable scope
var a = 6; 
(function() {
  a++;
  console.log('Inside the IIFE, variable a has value: ', a);
})();
console.log('After invoking IIFE, variable a has value: ', a);
// Value of a is available to the IIFE as a is a global variable



// Immediately-invoked Function Expressions (IIFE) and global & local variable scope
var a = 6;   // GLOBAL
(function() {
  var a = 2;   // LOCAL
  console.log('Inside the IIFE, variable a has value: ', a);   // LOCAL
})();
console.log('After invoking IIFE, variable a has value: ', a);   // GLOBAL
// Value of a is available to the IIFE as a is a global variable



// Immediately-invoked Function Expressions (IIFE) and changing variable values ...
for (var i = 0; i < 2; i++) {   // i is a global variable
(function() {
  console.log('Inside the IIFE, variable i has value: ', i);
})();
}
console.log('After invoking IIFE, variable i has value: ', i);


(function() {
  for (var i = 3; i < 5; i++) {   // i is a local variable
    console.log('Inside the IIFE, variable i has value: ', i);
  }
})();
console.log('After invoking IIFE, variable i has value: ', i);  // logs value 2 for i as the global value of i



// JS anonymous function as argument to other functions, e.g. setTimeout
var a = 4;
setTimeout(function() {
  console.log('After setTimeout, variable a has value: ', a);
}
,1000);

for (var b = 1; b < 4; b++) {
  console.log('In for loop, variable b has value: ', b);
  setTimeout(function() {
    console.log('After setTimeout (in loop), variable b has value: ', b);
  }
  ,(1000 * b));
}

for (var c = 1; c < 4; c++) {
  console.log('In for loop, variable c has value: ', c);
  setTimeout(function(x) {  // x is the parameter that takes on the value of c that was passed as argument
    console.log('After setTimeout (in loop), variable c has value: ', c, ' and x =', x);
  }
  ,(5000 * c), c);    // c (the c after the comma) is the argument passed into the anonymous function
}




