console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  var c = document.getElementsByClassName('animationInner');
  for (i = 0; i < c.length; i++) {
    drawCanvas(i);
  }
});


// Global variable declarations for variables used or likely to be used:
var i;
var j;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  var c = document.getElementsByClassName('animationInner');
  for (i = 0; i < c.length; i++) {
    c[i].addEventListener('mouseover', (function(x) {
      console.log('x =',x);
      return function(){
	    drawCanvasLarge(x);
	  }
	})(i));
    c[i].addEventListener('mouseout', (function(x) {
      console.log('x =',x);
      return function(){
	    drawCanvas(x);
	  }
	})(i));
  }
}


function drawCanvas(i) {
  console.log('drawCanvas function call');
  var c = document.getElementsByClassName('circles');
  //console.log(c);
  console.log('i =',i);
  var ctx = c[i].getContext('2d');
  ctx.clearRect(0, 0, 32, 32);
  ctx.beginPath();
  ctx.arc(16, 16, 12, 0, 2 * Math.PI);
  ctx.fillStyle = '#336699';
  ctx.fill();
}

function drawCanvasLarge(i) {
  console.log('drawCanvasLarge function call');
  var c = document.getElementsByClassName('circles');
  //console.log(c);
  console.log('i =',i);
  var ctx = c[i].getContext('2d');
  ctx.beginPath();
  ctx.arc(16, 16, 14, 0, 2 * Math.PI);
  ctx.fill();
}