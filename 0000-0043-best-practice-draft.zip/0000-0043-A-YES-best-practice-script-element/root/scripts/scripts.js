console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  myFunctionToSelectMyDiv();
  
});


function addMyEventListeners(){

};


function myFunctionToSelectMyDiv() {
  var selectedDiv = document.getElementById("myDiv");
  console.log('The selected Div:', selectedDiv);
}