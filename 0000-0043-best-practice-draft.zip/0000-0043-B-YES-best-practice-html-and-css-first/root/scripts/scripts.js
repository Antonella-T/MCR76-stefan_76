console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  myFunctionToSelectMyDiv();
  
});


function addMyEventListeners(){
  document.getElementById('secretButton').addEventListener('click', revealSecret);
};


function myFunctionToSelectMyDiv() {
  var selectedDiv = document.getElementById("myDiv");
  console.log('The selected Div:', selectedDiv);
}

 
function revealSecret() {
  document.getElementById('secret').innerHTML = 'Think again, I will not tell you my secret!';	
}
 
 