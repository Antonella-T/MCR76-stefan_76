console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  contentHousekeeping();
  
});


var d = new Date();


function addMyEventListeners(){
  
};


function contentHousekeeping() {

  document.getElementById('currentYear').innerText = d.getFullYear();

  var currentHour = d.getHours();
  switch(true) {
    case (currentHour < 0):
      var greeting = 'Good Evening';
      break;
    case (currentHour < 12):
      var greeting = 'Good Morning';
      break;
	case (currentHour < 18):
      var greeting = 'Good Afternoon';
      break;
    default:
      var greeting = 'Hello';
  }

  document.getElementById('greeting').innerText = greeting;
  
  switch (d.getDay()) {
    case 0:
      weekDay = "Sunday";
      break;
    case 1:
      weekDay = "Monday";
      break;
    case 2:
      weekDay = "Tuesday";
      break;
    case 3:
      weekDay = "Wednesday";
      break;
    case 4:
      weekDay = "Thursday";
      break;
    case 5:
      weekDay = "Friday";
      break;
    case 6:
      weekDay = "Saturday";
	  break;
	default:
	  weekDay = "not sure what day it is, sorry :(";
  }
  document.getElementById('weekDay').innerText = weekDay;

}


 
 