console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  $('body').css('backgroundColor', 'yellow');
  $('#wrapper').css('backgroundColor', 'silver');
  $('.para').css('backgroundColor', 'white');
    
});



function addMyEventListeners(){
  
};


 
 