console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  $('p').click(function(){
    console.log('A paragraph has been clicked');
  });

  
  $('body').css('backgroundColor', 'navy');
  $('#wrapper').css('backgroundColor', 'white');
  $('.para').css('backgroundColor', 'silver');
  $('.para').eq(1).css('backgroundColor', 'aqua');
  
  
  $('#txtExample1').mouseenter(function(){
    //console.log("You entered txtExample1!");
    $('#txtExample1').css('backgroundColor', 'yellow');
  });
    
  $('#txtExample1').mouseleave(function(){
    //console.log("You left txtExample1!");
    $('#txtExample1').css('backgroundColor', 'white');
  });

  $(window).scroll(function(){
    console.log('Page has been scrolled');
  });
    
    
});





 
 