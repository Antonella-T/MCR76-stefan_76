console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
  $('#show1').click(function() {
    //console.log('show1 has been clicked!');
    showPara('#para1');
  }
  );
  $('#hide1').click(function() {
    //console.log('hide1 has been clicked!');
    hidePara('#para1');
  }
  );

    
});


function showPara(paraId){
  console.log('show1 has been clicked!');
  console.log(paraId + ' will show');
  $(paraId).show();
}

function hidePara(paraId){
  console.log('hide1 has been clicked!');
  console.log('para1 will hide');
  $(paraId).hide();
}



 
 