console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});


function addMyEventListeners(){

  $('#result').on('click', function(){
    var result = rollDice('dice_inner');
    console.log(result);
    console.log(Object.keys(result));
  });
      
};


function rollDice(className) {

  // all dice with same className must have equal width and height values

  var dice = $('.' + className);
  console.log(dice);

  var width = dice.eq(0).width();
  console.log(width);

  var results = {};

  $.each(dice, function(i){
    
    console.log(dice.eq(i).attr('id'));  
    var result = Math.floor(Math.random()*6+1); //random number 1 to 6
    var delay = Math.floor(Math.random()*8+4);  //random number 4 to 12
    console.log('result: ', result);
    console.log('delay: ', delay);
    console.log('i: ', i);
    $(this).animate({left: (width/100*3 * Math.pow(-1, i%2)) +'px'}, 15*delay, function(){
    $(this).css('background-position', '0 -' + (6 + i%2) * width + 'px');
      }).delay(15*delay).animate({top: (-1 * width/100*3 * Math.pow(-1, i%2)) +'px'}, 15*delay, function(){
        $(this).css('background-position', '0 -' + (7 + i%2) * width + 'px');
      }).delay(15*delay).animate({top: (width/100*2 * Math.pow(-1, i%2)) +'px'}, 15*delay, function(){
        $(this).css('background-position', '0 -' + (8 + i%2) * width + 'px');
      }).delay(15*delay).animate({left: (-1 * width/100*2 * Math.pow(-1, i%2)) +'px'}, 15*delay, function(){
        $(this).css('background-position', '0 -' + (9 + i%2) * width + 'px');
      }).delay(15*delay).animate({left: '0px', top: '0px'}, 15*delay, function(){
        $(this).css('background-position', '0 -' + (result-1) * width + 'px')
      });
    results[$(this).attr('id')] = result;
  });
  
  return results;
  
}

 
 