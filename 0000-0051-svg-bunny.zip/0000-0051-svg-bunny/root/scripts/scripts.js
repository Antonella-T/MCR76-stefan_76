console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  
$('#leftEar').velocity({opacity: 1}, 2000 );
  
  
});


function addMyEventListeners(){


      
};



