console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  
  
  
});


function addMyEventListeners(){

  $('#backToTop').click(function(){
    console.log('Button has been clicked');
    scrollToTop();
  });
      
  // add a scroll event to show / hide the backToTop button   
  
};

function scrollToTop(){
  console.log('scrollToTop() has been invoked');
  // replace this line with the code from the stream
}







