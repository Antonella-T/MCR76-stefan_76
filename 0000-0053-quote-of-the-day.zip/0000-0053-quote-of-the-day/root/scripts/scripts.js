console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  quoteOfTheDay();
  
  
});


function addMyEventListeners(){

      
};




function quoteOfTheDay() {
  console.log('quoteOfTheDay function called');
  // replace my sample quotes with real quotes
  var quotes = ['First Quote Of The Day ...', 'Second Quote Of The Day ...', 'Third Quote Of The Day ...', 'Fourth Quote Of The Day ...'];
  // log and observe 
  //  Math.random()
  //  Math.random() * by a value
  //  use Math.floor() to return integer values only (values without decimal part)
  //  how would you generate a number between 1 - 6  ?
  $('#quoteOfTheDay').html(quotes[Math.floor(Math.random() * quotes.length)]);
}






