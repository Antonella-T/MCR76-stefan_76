console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  startSlider(0);
 
});


function addMyEventListeners(){


};


function startSlider(i) {
  $('.sliderImages').each(function() {
    $(this).animate({'opacity': 0}, 500);
  });
  //$('.sliderImages').eq(i).css({'opacity': 1});
  $('.sliderImages').eq(i).delay(2000).animate({'opacity': 1}, 500);
  i++;
  if (i == $('.sliderImages').length){i = 0};
  setTimeout(startSlider, 2000, i);
}





