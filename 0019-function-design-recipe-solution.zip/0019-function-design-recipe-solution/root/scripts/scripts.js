console.log('Script file loaded.');

document.addEventListener("DOMContentLoaded", function(){

  console.log('HTML file loaded and parsed.');

  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA BELOW ONLY! *** */



console.log(isItNumber(1234)) // expected output true
console.log(isItNumber('1234')) // expected output false
console.log(isItNumber('one')) // expected output false
console.log(isItNumber(0)) // expected output true
console.log(isItNumber()) // expected output false




  /* *** FOR OUR UPCOMING EXERCISES, PLEASE
         MAKE USE OF THE AREA ABOVE ONLY! *** */
  
});




 /**
  * identify if a value is of data type number or not.
  * @param {Any} anyValue - value that is being passed into the function for 
                            evaluation. Data type is not specified as this value
                            could be of any type.
  * @return {Boolean} - true if the data type of parameter anyValue is a number
  *
  * isItNumber(1234)
  * true
  * isItNumber('1234')
  * false
  * isItNumber('one')
  * false
  * isItNumber(0)
  * true
  * isItNumber()
  * false
  *
  * STRATEGY: make use of the JavaScript 'typeof' Operator
  */ 
function isItNumber(anyValue) {
  // IF data type of anyValue = number:
  if (typeof anyValue == 'number') {
    // OUTPUT boolean TRUE by returning true
    return true;
    }
  // ELSE:
  else {
    // OUTPUT boolean FALSE by returning false
    return false;
    }
}
