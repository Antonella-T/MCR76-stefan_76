console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});



// Default variable declarations for variables we are likely to use:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

}



/**
 * Change bg colour of a div that was selected with a number
 * @param {} - number and colour are read from HTML form
 * @return {boolean} - true if colour was changed
 * 
 * STRATEGY: use getElementById and/or getElementByClassName, use style object
 */ 
function changeColor() {
  // Clear the console to have one set of colours only
  console.clear();
  
  // START changeColor
  // INPUT from HTML form the selected number and assign to divNumber
  var divNumber = document.getElementById('divNumber').value;
  console.log('divNumber: ', divNumber);
  
  // INPUT from HTML form the selected colour and assign to divColour
  var divColour = document.getElementById('divColour').value;
  console.log('divColour: ', divColour);
 
  // INPUT all div elements with class colrdDiv and assign to divElements
  var divElements = document.getElementsByClassName('colrdDiv');

  // Change bg colour of element from divElements with index (divNumber-1) to divColour
  divElements[divNumber-1].style.backgroundColor = divColour;
 
  // OUTPUT all bg colour properties from all divElements to console
  for (i = 0; i < divElements.length; i++) {
    console.log('Div ' + (i + 1) + ': ' + divElements[i].style.backgroundColor);
  }

  // END changeColor
	
  
}