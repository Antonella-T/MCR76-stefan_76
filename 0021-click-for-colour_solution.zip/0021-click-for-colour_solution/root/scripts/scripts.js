console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
});



// Default variable declarations for variables we are likely to use:
var i;


/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){

}



/**
 * Change bg colour of a div that was selected with a number
 * @param {} - number and colour are read from HTML form
 * @return {boolean} - true if colour was changed
 * 
 * STRATEGY: use getElementById and/or getElementByClassName, use style object
 */ 
function changeColor() {
  // START changeColor
  // INPUT from HTML form the selected number and assign to divNumber
  var divNumber = document.getElementById('divNumber').value;
  console.log('divNumber: ', divNumber);
  
  // INPUT from HTML form the selected colour and assign to divColour
  var divColour = document.getElementById('divColour').value;
  console.log('divColour: ', divColour);
  
  // INPUT div element that we want to change the background colour and assign to divElement
  var divElement = document.getElementById('div' + divNumber);
  console.log('divElement: ', divElement);
  
  // Change background colour of divElement to divColour
  divElement.style.backgroundColor = divColour;	
  
  // INPUT all bg colours from all divs
  var allDivs = document.getElementsByClassName('colrdDiv');
  
  // OUTPUT all bg colours to console
  for (i = 0; i < allDivs.length; i++) {
    console.log('Div ' + (i + 1) + ': ' + allDivs[i].style.backgroundColor)
  }
  
  // END changeColor
	
  
}