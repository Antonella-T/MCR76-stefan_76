console.log('Script file loaded.');

document.addEventListener('DOMContentLoaded', function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  
});


// Global variable declarations for variables used or likely to be used:
var i;
var j;

/* Keep this function declaration for future projects. Don't need to remove it, 
   even if it doesn't do anything for this exercise.  */
function addMyEventListeners(){
  var accHs = document.getElementsByClassName('accH');
  // https://stackoverflow.com/questions/30354136/function-call-with-parameters-to-addeventlistener-inside-a-loop
  for (i = 0; i < accHs.length; i++) {
    accHs[i].addEventListener('click', (function(y) {
      return function(){
        myAccordion(y);
      }
    })(i));  
  }
}


function myAccordion(x) {
  console.log(x);
  var accPs = document.getElementsByClassName('accP');
  if (accPs[x].style.height != '10px') {
    console.log(accPs[x].style.height);
	accPs[x].style.height = '10px';
  }
  else {
    console.log(accPs[x].style.height);
	accPs[x].style.height = '';
  }
  
}

