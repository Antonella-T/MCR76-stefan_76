x = new Date();
i = x.getHours();
if (i >= 4 && i < 12) {
  document.getElementById('greeting').innerText = 'A very good morning to';
  }
else if (i >= 12 && i < 18) {
  document.getElementById('greeting').innerText = 'A very pleasent good evening to ';
  }
else if (i >= 18 && i < 22) {
  document.getElementById('greeting').innerText = 'A very good afternoon ';
  }
else {
  document.getElementById('greeting').innerText = 'Hello to ';
  }
