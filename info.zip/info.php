<?php

phpinfo();

exit;

?>